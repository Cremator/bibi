cd /root/xmr-stak-rx-linux-1.0.4-cpu/
/usr/bin/screen -d -m -S xmr /root/xmr-stak-rx-linux-1.0.4-cpu/xmr-stak-rx
